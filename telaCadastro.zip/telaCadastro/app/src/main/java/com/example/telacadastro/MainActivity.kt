import android.os.Bundle
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.telacadastro.R
import android.widget.Switch
import android.text.method.PasswordTransformationMethod
import android.text.Editable


class CreateAccountActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var txtConfirmar = findViewById<EditText>(R.id.txtConfirmar)
        var swi2 = findViewById<Switch>(R.id.swi2)

        swi2.setOnCheckedChangeListener{_, isChecked ->
            if (isChecked) {
                // Se o Switch estiver marcado, mostrar a senha
                txtConfirmar.transformationMethod = null
            } else {
                // Se o Switch não estiver marcado, esconder a senha
                txtConfirmar.transformationMethod = PasswordTransformationMethod.getInstance()
            }
        }

        txtConfirmar.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Salva a posição atual do cursor
                val selectionStart: Int = txtConfirmar.selectionStart
                val selectionEnd: Int = txtConfirmar.selectionEnd

                // Atualiza o texto do EditText com a nova formatação
                txtConfirmar.transformationMethod =
                    if (swi2.isChecked) null else PasswordTransformationMethod.getInstance()

                // Restaura a posição do cursor
                txtConfirmar.setSelection(selectionStart, selectionEnd)
            }
        })

        var txtSenha = findViewById<EditText>(R.id.txtSenha)
        var swi1 = findViewById<Switch>(R.id.swi1)

        swi1.setOnCheckedChangeListener{_, isChecked ->
            if (isChecked) {

                txtSenha.transformationMethod = null
            } else {

                txtSenha.transformationMethod = PasswordTransformationMethod.getInstance()
            }
        }

        txtSenha.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

                val selectionStart: Int = txtSenha.selectionStart
                val selectionEnd: Int = txtSenha.selectionEnd


                txtSenha.transformationMethod =
                    if (swi1.isChecked) null else PasswordTransformationMethod.getInstance()


                txtSenha.setSelection(selectionStart, selectionEnd)
            }
        })


        val buttonCreateAccount: Button = findViewById(R.id.btnCriar)
        buttonCreateAccount.setOnClickListener {
            if (validateFields()) {

                showSuccessMessage()
            } else {

                Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private fun validateFields(): Boolean {
        val txtNome: EditText = findViewById(R.id.txtNome)
        val txtSobrenome: EditText = findViewById(R.id.txtSobrenome)
        val txtEmail: EditText = findViewById(R.id.txtEmail)
        val txtPhone: EditText = findViewById(R.id.txtPhone)
        val txtSenha: EditText = findViewById(R.id.txtSenha)
        val txtConfirmar: EditText = findViewById(R.id.txtConfirmar)

        return txtNome.text.isNotEmpty() &&
                txtSobrenome.text.isNotEmpty() &&
                txtEmail.text.isNotEmpty() &&
                txtPhone.text.isNotEmpty() &&
                txtSenha.text.isNotEmpty() &&
                txtConfirmar.text.isNotEmpty()
    }

    private fun showSuccessMessage() {
        Toast.makeText(this, "Conta criada com sucesso!", Toast.LENGTH_SHORT).show()
    }

}



